<!DOCTYPE html>
<html>
<head>
	<title>room information </title>
	<meta charset="utf-8" />
	<meta name="author" content="group 88"/> 
		
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /><!-- //Bootstrap Css -->
	<link href="css/font-awesome.css" rel="stylesheet"><!-- //Font-awesome Css -->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- //Required Css -->
	<link href="//fonts.googleapis.com/css?family=Raleway:300,400,500,600,800" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
</head>
<body>
<div class="inner-bnr">
		<div class="header-bottom">
			<div class="container">
				<nav class="navbar navbar-default">
					<div class="navbar-header">
						<div class="logo">
							<h1><a class="navbar-brand"><span>Stu</span>dent</a></h1>
						</div>
					</div>

					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
						<nav class="cl-effect-1" id="cl-effect-1">
							<ul class="nav navbar-nav">
								<li><a href="index.html" data-hover="Home">Home</a></li>
                                <li><a href="community.php" data-hover="SUB-COMMUNITY">SUB-COMMITTEE</a></li>
								<li class="dropdown menu__item">
									<a href="#" class="dropdown-toggle menu__link active" data-toggle="dropdown" data-hover="Pages" role="button" aria-haspopup="true"
									    aria-expanded="false">Attendees<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="student.php">Student</a></li>
										<li><a href="professionals.php">Professionals</a></li>
                                        <li><a href="sponsors.php">Sponsors</a></li>
									</ul>
								</li>
								<li><a href="hotel.php" data-hover="hotel">HOTEL</a></li>
								<li><a href="day.php" data-hover="CONFERENCE-SCHEDULE">CONFERENCE-SCHEDULE</a></li>
                                <li><a href="company.php" data-hover="company">COMPANY</a></li>
                                <li><a href="job.php" data-hover="JOB-POSTED">JOB-POSTED</a></li>
                                <li><a href="intake.php" data-hover="intake">CONFERENCE-INTAKE</a></li>
                                <li class="dropdown menu__item">
									<a href="#" class="dropdown-toggle menu__link active" data-toggle="dropdown" data-hover="Pages" role="button" aria-haspopup="true"
									    aria-expanded="false">ADD<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="attendees.php">Add Attendees</a></li>
										<li><a href="company.html">Add company</a></li>
                                        <li><a href="addjob.php">Add job</a></li>
									</ul>
								</li>
							</ul>
						</nav>
					</div>
				</nav>
			</div>
		</div>
	</div>
    
    <div class="about-bottom inner-padding">
	   <div class="container">
		  <h3 class="title-txt">Conference Attendees: Sponsors</h3>
              <?php
                $pdo = new PDO('mysql:host=localhost;dbname=conference', "root", "");
                $sql = "select attendees.attendees_id,attendees.fname,attendees.lname,phone,comp_name,email from attendees INNER JOIN works_in ON role = 'sponsor'and attendees.attendees_id=works_in.attendees_id";
                $stmt = $pdo->prepare($sql);   #create the query
                $stmt->execute();
                echo "<table><tr><th>Attendees Id</th><th>First Name</th><th>Last Name</th><th>company Name</th><th>Phone Number</th><th>Email</th></tr>";
                while ($row = $stmt->fetch()) {
                    echo "<tr><td>".$row["attendees_id"]."</td><td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["comp_name"]."</td><td>".$row["phone"]."</td><td>".$row["email"]."</td></tr>";
                }
                ?>
               <div class="clearfix"> </div>
        </div>
    </div>
    <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
	<!-- stats -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countup.js"></script>
		<script>
			$('.counter').countUp();
		</script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>	
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html> 