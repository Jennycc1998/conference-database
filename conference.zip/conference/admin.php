<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="author" content="group 88"/> 
		
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /><!-- //Bootstrap Css -->
	<link href="css/font-awesome.css" rel="stylesheet"><!-- //Font-awesome Css -->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- //Required Css -->
	<!--fonts-->
	<link href="//fonts.googleapis.com/css?family=Raleway:300,400,500,600,800" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
	
</head>

<body>
     	<div class="inner-bnr">
		<div class="header-bottom">
			<div class="container">
				<nav class="navbar navbar-default">
					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
						<nav class="cl-effect-1" id="cl-effect-1">
							<ul class="nav navbar-nav">
								<li><a href="index.html" data-hover="Home">Home</a></li>
                                <li><a href="community.php" data-hover="SUB-COMMUNITY">SUB-COMMITTEE</a></li>
								<li class="dropdown menu__item">
									<a href="#" class="dropdown-toggle menu__link active" data-toggle="dropdown" data-hover="Pages" role="button" aria-haspopup="true"
									    aria-expanded="false">Attendees<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="student.php">Student</a></li>
										<li><a href="professionals.php">Professionals</a></li>
                                        <li><a href="sponsors.php">Sponsors</a></li>
									</ul>
								</li>
								<li><a href="hotel.php" data-hover="hotel">HOTEL</a></li>
								<li><a href="day.php" data-hover="CONFERENCE-SCHEDULE">CONFERENCE-SCHEDULE</a></li>
                                <li><a href="company.php" data-hover="company">COMPANY</a></li>
                                <li><a href="job.php" data-hover="JOB-POSTED">JOB-POSTED</a></li>
                                <li><a href="intake.php" data-hover="intake">CONFERENCE-INTAKE</a></li>
                                <li class="dropdown menu__item">
									<a href="#" class="dropdown-toggle menu__link active" data-toggle="dropdown" data-hover="Pages" role="button" aria-haspopup="true"
									    aria-expanded="false">ADD<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="attendees.php">Add Attendees</a></li>
										<li><a href="company.html">Add company</a></li>
                                        <li><a href="addjob.php">Add job</a></li>
									</ul>
								</li>
							</ul>
						</nav>
					</div>
				</nav>
			</div>
		</div>
	</div>
</body>
    
<?php
	$db = new mysqli("localhost","root","","conference");
    if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
} 
?>
  
<!-- sub-committee-->
    <div class="about-bottom inner-padding">
	   <div class="container">
           <?php
            if((isset($_POST["sub-communities"]))){
                $scom = $_POST['sub-communities'];
                echo "<table><tr><th>Members_ID</th><th>last_name</th><th>first_name</th></tr>";
                $pdo = new PDO('mysql:host=localhost;dbname=conference', "root", "");  
                $sql = "select members_ID, lname, fname from member where members_ID in (select members_ID from belongs_to where subcom_name = '$scom')";
                $stmt = $pdo->prepare($sql);  
                $stmt->execute([$scom]);
                if($stmt->rowCount()){
                    while ($row = $stmt->fetch()) {
                        echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td></tr>";
                        $pdo = null;
                    }
                }
            else{
                echo "<script type='text/javascript'>alert('sub-community empty!');</script>";
                echo'<script>setTimeout(window.location="community.php",3000);</script>';
                $pdo = null;
            }
            }
           ?>
            <div class="clearfix"> </div>
        </div>
    </div>

    
<!--hotel-->
    <div class="about-bottom inner-padding">
	   <div class="container">
            <?php
                if(isset($_POST['room'])){
                    $rnum = $_POST['room'];
                    echo "<table><tr><th>first_name</th><th>last_name</th></tr>";
                    $pdo = new PDO('mysql:host=localhost;dbname=conference', "root", "");   
                    $sql = "select fname, lname from attendees where attendees_id in (select attendees_id from lives_in where room_num = $rnum) ";
                    $stmt = $pdo->prepare($sql);   
                    $stmt->execute([$rnum]); 
                    if($stmt->rowCount()){
                        while ($row = $stmt->fetch()) {
                            echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td></tr>";
                            $pdo = null; 
                        }
                    }
                else{
                    echo "<script type='text/javascript'>alert('room empty!');</script>";
                    echo'<script>setTimeout(window.location="hotel.php",3000);</script>';
                    $pdo = null;
                }
                }
            ?>
           <div class="clearfix"> </div>
        </div>
    </div>
    
    
<!--add attendees-->
<?php
if (isset($_POST['att_submit'])){
      session_start();
	  
      $id = mysqli_escape_string($db,$_POST['id']);
      $Last_name = mysqli_escape_string($db,$_POST['lastname']);
      $First_name = mysqli_escape_string($db,$_POST['firstname']);
      $Program = mysqli_escape_string($db,$_POST['program']);
      $Phone = mysqli_escape_string($db,$_POST['phone']);
	  $Room = mysqli_escape_string($db,$_POST['room_num']);
	  $Role = mysqli_escape_string($db,$_POST['role']);
      $Company = mysqli_escape_string($db,$_POST['company']);
      $Email = mysqli_escape_string($db,$_POST['email']);
      $dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
      $sql = "select * from attendees where attendees_id = '$id'";
      $stmt = $dbh ->query($sql);
      if(empty($id) || empty($Last_name) || empty($First_name) ){
            echo "<script type='text/javascript'>alert('You did not fill out the required fields.');</script>";
            echo'<script>window.location="attendees.php";</script>';
      }
	if ($stmt->rowCount()){
		echo "<script type='text/javascript'>alert('Attendees ID duplicates.');</script>";
        echo'<script>window.location="attendees.php";</script>';
	  
    }
    else{
        if($Role == "student"){
        $sql2 = "INSERT INTO attendees(attendees_id,fname,lname,role,program,phone,fee,email) VALUES('$id','$First_name','$Last_name','$Role','$Program',Null,'50','$Email')";
        if($db->query($sql2) === TRUE){
            sleep(1);
            echo "<script type='text/javascript'>alert('Successful inserted!');</script>";
            echo'<script>window.location="attendees.php";</script>';
        }
          if($Room != '1'){
              $sql3="update hotel_room set occupy = occupy+1 where room_num = '$Room'";
              $db->query($sql3);
              $sql = "INSERT INTO lives_in(attendees_id,fname,lname,room_num) VALUES('$id','$First_name','$Last_name','$Room')";
              $db->query($sql); 
          }
      }
	  else if($Role == "professional"){
            $sql = "INSERT INTO attendees(attendees_id,fname,lname,role,program,phone,fee,email) VALUES('$id','$First_name','$Last_name','$Role',Null,Null,'100','$Email')";
            if($db->query($sql) === TRUE){
                sleep(1);
                echo "<script type='text/javascript'>alert('Successful inserted!');</script>";
                echo'<script>window.location="attendees.php";</script>';
            }
      }
	  else if($Role == "sponsor"){
            $sql3 = "INSERT INTO attendees(attendees_id,fname,lname,role,program,phone,fee,email) VALUES('$id','$First_name','$Last_name','$Role',Null,'$Phone','0','$Email')";
            $db->query($sql3);
            $sql= "INSERT INTO works_in(attendees_id,fname,lname,comp_name) VALUES('$id','$First_name','$Last_name','$Company')";
            if($db->query($sql) === TRUE){
                sleep(1);
                echo "<script type='text/javascript'>alert('Successful inserted!');</script>";
                echo'<script>window.location="attendees.php";</script>';
            }
      }
	  
	  else{
		   echo "<script type='text/javascript'>alert('Sorry, the role you entered is invalid. Please try again.');</script>";
           echo'<script>window.location="attendees.php";</script>';
	  }
    }
  }
?>

<!--add company-->
<?php
if (isset($_POST['com_submit'])){
      session_start();
	  $dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
      $Company = mysqli_escape_string($db,$_POST['company']);
      $Sponsor = mysqli_escape_string($db,$_POST['sponsor']);
	  $sql = "select * from company where comp_name = '$Company'";
      $stmt = $dbh ->query($sql);
	    
      if(empty($Company) || empty($Sponsor)){

                echo "<script type='text/javascript'>alert('You did not fill out the required fields.');</script>";
                echo'<script>window.location="company.html";</script>';

      }
	if ($stmt->rowCount()){
	  echo "<script type='text/javascript'>alert('Company Already Existed!');</script>";
      echo'<script>window.location="company.html";</script>';
	  
	}
	else{
		
	  if ($Sponsor == "Platinum"){
		$sql = "INSERT INTO company(comp_name,sponsor_level,sponsor_fee,email_num,has_sent) VALUES('$Company','$Sponsor','10000','5','0')";
	  }
	  else if($Sponsor == "Gold"){
		$sql = "INSERT INTO company(comp_name,sponsor_level,sponsor_fee,email_num,has_sent) VALUES('$Company','$Sponsor','5000','4','0')";
	  }
	  else if($Sponsor == "Silver"){
		$sql = "INSERT INTO company(comp_name,sponsor_level,sponsor_fee,email_num,has_sent) VALUES('$Company','$Sponsor','3000','3','0')";		  
	  }
	  else if($Sponsor == "Bronze"){
		$sql = "INSERT INTO company(comp_name,sponsor_level,sponsor_fee,email_num,has_sent) VALUES('$Company','$Sponsor','1000','0','0')";
	  }
	  else{
		   echo "<script type='text/javascript'>alert('Wrong sponsor level!');</script>";
                echo'<script>window.location="company.html";</script>';
	  }

	  if($db->query($sql) === TRUE){

          sleep(1);
		  echo "<script type='text/javascript'>alert('Successful inserted!');</script>";
          echo'<script>window.location="company.html";</script>';

      }
		  
	  else{
		echo "No",$dbh -> error;
		  }
	}

  }   
?>
    
<!--update session information-->
<?php
if(isset($_POST['update'])){
    $dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
    $id = $_POST['session_id'];
    $update_date = $_POST['session_date'];
    $update_start = $_POST['start_time'];
    $update_end = $_POST['end_time'];
    $update_room = $_POST['room_location'];
    $sql = "SELECT * FROM sessions WHERE session_date='$update_date' AND start_time='$update_start' AND room_location='$update_room'";
    $stmt = $dbh->query($sql);
  if($stmt->rowCount()){
       echo "<script type='text/javascript'>alert('Schedule Conflict!');</script>";
       echo'<script>window.location="day.php";</script>';
    }
   else{
       if($dbh->exec("UPDATE sessions SET session_date=$update_date,start_time='$update_start',end_time = '$update_end',room_location='$update_room' WHERE session_id = '$id'")){
          echo "<script type='text/javascript'>alert('Successfully updated!');</script>";
          echo'<script>window.location="day.php";</script>';
          $dbh = null;
       }
       else{
          echo "<script type='text/javascript'>alert('Failed! check if you have a typo!');</script>";
          echo'<script>setTimeout(window.location="day.php",3000);</script>';
          $dbh = null;
    }
   }
}
?>
 
<!--delete company-->
<?php
if(isset($_GET['comp_name'])){
  $dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
  $name = $_GET['comp_name'];
  $dbh->exec("DELETE FROM attendees WHERE attendees_id in(select attendees_id from works_in where comp_name= '$name')");
  if($dbh->exec("DELETE FROM company WHERE comp_name = '$name'")){
        echo "<script type='text/javascript'>alert('Successful deleted!');</script>";
        echo'<script>window.location="company.php";</script>';
        $dbh = null;
    }
    else{
        echo "<script type='text/javascript'>alert('Failed!');</script>";
        echo'<script>setTimeout(window.location="company.php",3000);</script>';
        $dbh = null;
    }
}
?>
    
<!--company information>-->
    <div class="about-bottom inner-padding">
	   <div class="container">
           <?php
            if(isset($_GET['comp_info'])){
                $dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
                $name = $_GET['comp_info'];
                echo "<table><tr><th>first_name</th><th>last_name</th></tr>";
                $sql = "select attendees.fname, attendees.lname from attendees,works_in where attendees.attendees_id = works_in.attendees_id and works_in.comp_name ='$name'";
                $stmt = $dbh->prepare($sql);   
                $stmt->execute([$name]); 
                if($stmt->rowCount()){
                    while ($row = $stmt->fetch()) {
                        echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td></tr>";
                        $pdo = null; 
                    }
                }
                else{
                    echo "<script type='text/javascript'>alert('This conpamy did not send any sponsor!');</script>";
                    echo'<script>setTimeout(window.location="company.php",3000);</script>';
                    $pdo = null;
                }
            }
        ?>
        </div>
    </div>

<!--add email-->
    <?php
        if(isset($_GET['add_email'])){
        $dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
        $name = $_GET['add_email'];
        $sql = "update company set has_sent = has_sent+1 where comp_name = '$name' and has_sent < email_num";
        $stmt = $dbh->prepare($sql);   
        $stmt->execute([$name]); 
        echo'<script>window.location="company.php";</script>';
        }
    ?>
    
<!--add job-->
<?php
        if (isset($_POST['job_submit'])){
        session_start();
		$dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
        $Jobid = mysqli_escape_string($db,$_POST['jobid']);
        $Title = mysqli_escape_string($db,$_POST['title']);
        $City = mysqli_escape_string($db,$_POST['city']);
        $Province = mysqli_escape_string($db,$_POST['province']);
        $Rate = mysqli_escape_string($db,$_POST['rate']);
        $Company = mysqli_escape_string($db,$_POST['selectcompany']);
        $sql = "select * from job_ads where job_id = '$Jobid'";
        $stmt = $dbh ->query($sql);
        if(empty($Jobid) || empty($Title) || empty($City) || empty($Province) || empty($Rate) || empty($Company)){
                echo "<script type='text/javascript'>alert('You did not fill out the required fields.');</script>";
                echo'<script>window.location="addjob.php";</script>';
      }  
        else{
            if($stmt->rowCount()){
              echo "<script type='text/javascript'>alert('Attendees ID duplicates.');</script>";
              echo'<script>window.location="attendees.php";</script>';
            }
            else{
              $sql = "INSERT INTO job_ads(job_id,job_title,city,province,pay_rate,comp_name) VALUES('$Jobid','$Title','$City','$Province','$Rate','$Company')";  
  
            }
        }
    if($db->query($sql) === TRUE){
          sleep(1);
          echo "<script type='text/javascript'>alert('Successful inserted!');</script>";
          echo'<script>window.location="addjob.php";</script>';
      }
  }
?>


<div class="about-bottom inner-padding">
	   <div class="container">
<?php

   $pdo = new PDO('mysql:host=localhost;dbname=conference', "root", "");
   
   if(isset($_GET['speaker_name'])){
	echo "<table><tr><th>first_name</th><th>last_name</th></tr>";
	$speaker = $_GET['speaker_name'];   
    $stmt=$pdo->query("select speak_for.fname,speak_for.lname from speak_for where session_id = '$speaker'");
	while ($row = $stmt->fetch()) {
        echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td></tr>";
   }
   }
?>
 </div>
    </div>
    
    <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countup.js"></script>
		<script>
			$('.counter').countUp();
		</script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>	
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</html>