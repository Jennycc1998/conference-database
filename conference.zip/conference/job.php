<!DOCTYPE html>
<html>
<head>
	<title>room information </title>
	<meta charset="utf-8" />
	<meta name="author" content="group 88"/> 
		
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /><!-- //Bootstrap Css -->
	<link href="css/font-awesome.css" rel="stylesheet"><!-- //Font-awesome Css -->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- //Required Css -->
	<!--fonts-->
	<link href="//fonts.googleapis.com/css?family=Raleway:300,400,500,600,800" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
</head>
<body>
    <div class="inner-bnr">
		<div class="header-bottom">
			<div class="container">
				<nav class="navbar navbar-default">
					<div class="navbar-header">
						<div class="logo">
							<h1><a class="navbar-brand"><span>JOB</span></a></h1>
						</div>
					</div>

					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
						<nav class="cl-effect-1" id="cl-effect-1">
							<ul class="nav navbar-nav">
								<li><a href="index.html" data-hover="Home">Home</a></li>
                                <li><a href="community.php" data-hover="SUB-COMMUNITY">SUB-COMMITTEE</a></li>
								<li class="dropdown menu__item">
									<a href="#" class="dropdown-toggle menu__link active" data-toggle="dropdown" data-hover="Pages" role="button" aria-haspopup="true"
									    aria-expanded="false">Attendees<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="student.php">Student</a></li>
										<li><a href="professionals.php">Professionals</a></li>
                                        <li><a href="sponsors.php">Sponsors</a></li>
									</ul>
								</li>
								<li><a href="hotel.php" data-hover="hotel">HOTEL</a></li>
								<li><a href="day.php" data-hover="CONFERENCE-SCHEDULE">CONFERENCE-SCHEDULE</a></li>
                                <li><a href="company.php" data-hover="company">COMPANY</a></li>
                                <li><a href="job.php" data-hover="JOB-POSTED">JOB-POSTED</a></li>
                                <li><a href="intake.php" data-hover="intake">CONFERENCE-INTAKE</a></li>
                                <li class="dropdown menu__item">
									<a href="#" class="dropdown-toggle menu__link active" data-toggle="dropdown" data-hover="Pages" role="button" aria-haspopup="true"
									    aria-expanded="false">ADD<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="attendees.php">Add Attendees</a></li>
										<li><a href="company.html">Add company</a></li>
                                        <li><a href="addjob.php">Add job</a></li>
									</ul>
								</li>
							</ul>
						</nav>
					</div>
				</nav>
			</div>
		</div>
	</div>
    

    <div class="about-bottom inner-padding">
	  <div class="container">
		<h3 class="title-txt">I wanna see the job posted by:</h3>
             <div class="about-bott-right">
					 <form method = "post" action = "job.php">
                     <div class="form-left-w3l">
                     <?php
                       $mysqli = new mysqli('localhost','root','','conference');
                       $resultSet = $mysqli ->query("select comp_name from company");
                     ?>
                     <select name = "com">
                        echo "<option >All</option>";
                     <?php
                        while($rows = $resultSet->fetch_assoc())
                        {
                            $comp_name = $rows['comp_name'];
                            echo "<option value = '$comp_name'>$comp_name</option>";
                        }
                    ?>
                    </select>
                    </div>
                    <button type="submit"name ="submit">CONFIRM</button>
                    </form>
            </div>
            <div class="clearfix"> </div>
              <?php
                if(isset($_POST['submit'])){
                    $cname = $_POST['com'];
                    if ($cname=='All'){
                        $dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
                        $rows = $dbh->query("select * from job_ads");
                        echo "<table><tr><th>job id</th><th>job title</th><th>city</th><th>province</th><th>pay rate</th><th>company name</th></tr>";
                        foreach($rows as $row){
                            echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td></tr>";
                        }
                    }
                else{
                    $dbh = new PDO('mysql:host=localhost;dbname=conference', "root", "");
                    $rows = $dbh->query("select * from job_ads where comp_name = '$cname'");
                    echo "<table><tr><th>job id</th><th>job title</th><th>city</th><th>province</th><th>pay rate</th><th>company name</th></tr>";
                    foreach($rows as $row){
                    echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td></tr>";
                    }
                }
                }       
            ?>
       </div>
    </div>
    
    <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
	<!-- stats -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countup.js"></script>
		<script>
			$('.counter').countUp();
		</script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>	
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
    </body>
</html>